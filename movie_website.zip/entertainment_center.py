# coding=utf-8
import fresh_tomatoes
import media

pirates5 = media.Movie("Pirates of the Caribbean",
	"Gore Verbinski",
	"26 May 2017",
	"Pirates of the Caribbean: Dead Men Tell No Tales is an upcoming American fantasy swashbuckler film, and the fifth installment in the Pirates of the Caribbean film series. ",
	"https://66.media.tumblr.com/917e24549bb89d10ff7ea504d3a5b70d/tumblr_ntb035thDV1sfb51zo1_500.jpg",
	"https://www.youtube.com/watch?v=w69ZgDfmKcA")
barcelona = media.Movie("Vicky Cristina Barcelona",
	"Woody Allen",
	"27 June 2009",
	"The plot centers on two American women, Vicky (Rebecca Hall) and Cristina (Scarlett Johansson), who spend a summer in Barcelona where they meet an artist, Juan Antonio (Javier Bardem), who is attracted to both of them while still enamored of his mentally and emotionally unstable ex-wife María Elena (Penélope Cruz).",
	"https://vickycristinabarcelona.files.wordpress.com/2008/06/vicky-cristina-barcelona-inv.jpg",
	"https://www.youtube.com/watch?v=B-RdUcXAKiw")
big_hero = media.Movie("Big Hero 6",
	"Jordan Roberts",
	"28 February 2015",
	"The film tells the story of a young robotics prodigy named Hiro Hamada who forms a superhero team to combat a masked villain.",
	"http://vignette2.wikia.nocookie.net/disney/images/4/42/Big-Hero-6-poster-2-full.jpg","https://www.youtube.com/watch?v=z3biFxZIJOQ")
zootopia = media.Movie("Zootopia",
	"Byron Howard",
	"4 March 2016",
	"In a city of anthropomorphic animals, a rookie bunny cop and a cynical con artist fox must work together to uncover a conspiracy.",
	"http://sumnersunsettheatre.com/wp-content/uploads/Zootopia-Poster.jpg",
	"https://www.youtube.com/watch?v=jWM0ct-OLsM")
kingsman = media.Movie("Kingsman: The Secret Service",
	"Jane Goldman",
	"27 March 2015",
	"A spy organization recruits an unrefined, but promising street kid into the agency's ultra-competitive training program, just as a global threat emerges from a twisted tech genius.",
	"https://monsterzeronj.files.wordpress.com/2015/07/kingsman-poster-main-1.jpg",
	"https://www.youtube.com/watch?v=kl8F-8tR8to"
	)
before_sunrise = media.Movie("Before Sunrise",
	"Richard Linklate",
	"2 September 1995",
	"A young man and woman meet on a train in Europe, and wind up spending one evening together in Vienna. Unfortunately, both know that this will probably be their only night together.",
	"http://img.goldposter.com/2015/05/Before-Sunrise_poster_goldposter_com_7.jpg",
	"https://www.youtube.com/watch?v=9v6X-Dytlko")
movies=[pirates5,barcelona,big_hero,zootopia,kingsman,before_sunrise]
fresh_tomatoes.open_movies_page(movies)